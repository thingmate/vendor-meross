import { AsyncTask, IAsyncTaskConstraint } from '@lirx/async-task';
import { createMerossPacket, ICreateMerossPacketOptions } from '../create/create-meross-packet';
import { ISendMerossPacketOptions, sendMerossPacket } from './send-meross-packet';

/**
 * @deprecated
 */
export interface ICreateAndSendMerossPacketOptions<GPayload> extends //
  ICreateMerossPacketOptions<GPayload>,
  Omit<ISendMerossPacketOptions, 'packet'>
//
{
}

/**
 * @deprecated
 */
export function createAndSendMerossPacket<GRequestPayload, GResponsePayload extends IAsyncTaskConstraint<GResponsePayload>>(
  options: ICreateAndSendMerossPacketOptions<GRequestPayload>,
): AsyncTask<GResponsePayload> {
  return sendMerossPacket<GResponsePayload>({
    ...options,
    packet: createMerossPacket<GRequestPayload>(options),
  });
}


