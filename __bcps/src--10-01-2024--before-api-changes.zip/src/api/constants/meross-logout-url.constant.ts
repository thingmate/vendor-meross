import { MEROSS_URL } from './meross-url.constant';

export const MEROSS_LOGOUT_URL = `${MEROSS_URL}/v1/Profile/logout`;
