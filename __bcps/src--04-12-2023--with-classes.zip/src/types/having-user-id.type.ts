export type IUserId = string;

export interface IHavingUserId {
  readonly userId: IUserId;
}
