import {
  ISmartPlugThing,
  Thing,
  OnlineThingPropertyName,
  OnOffThingPropertyName,
  PowerConsumptionThingPropertyName,
  PowerConsumptionHistoryThingPropertyName,
  DescriptionThingPropertyName,
  ISmartPlugProperties,
} from '@thingmate/wot-scripting-api';
import {
  IMerossOnOffThingPropertyOptions,
  MerossOnOffThingProperty,
} from '../../../async-value/onoff/meross-on-off-thing-property.class';
import {
  IMerossOnlineThingPropertyOptions,
  MerossOnlineThingProperty,
} from '../../../async-value/meross-online-thing-property/meross-online-thing-property.class';
import {
  IMerossPowerConsumptionHistoryThingPropertyOptions,
  MerossPowerConsumptionHistoryThingProperty,
} from '../../../async-value/meross-power-consumption-history-thing-property/meross-power-consumption-history-thing-property.class';
import {
  IMerossPowerConsumptionThingPropertyOptions,
  MerossPowerConsumptionThingProperty,
} from '../../../async-value/meross-power-consumption-thing-property/meross-power-consumption-thing-property.class';
import {
  MerossDescriptionThingProperty,
  IMerossDescriptionThingPropertyOptions,
} from '../../../async-value/description/meross-description-thing-property.class';

export interface IMerossMss310SmartPlugThingOptions extends //
  IMerossDescriptionThingPropertyOptions,
  IMerossOnlineThingPropertyOptions,
  IMerossOnOffThingPropertyOptions,
  IMerossPowerConsumptionThingPropertyOptions,
  IMerossPowerConsumptionHistoryThingPropertyOptions
//
{
}

// export type IMerossSmartPlugThing = ISmartPlugThing<IMerossThingDescription>;

export class MerossMss310SmartPlugThing extends Thing<ISmartPlugProperties> implements ISmartPlugThing {
  constructor(
    options: IMerossMss310SmartPlugThingOptions,
  ) {
    super([
      [DescriptionThingPropertyName, new MerossDescriptionThingProperty(options)],
      [OnlineThingPropertyName, new MerossOnlineThingProperty(options)],
      [OnOffThingPropertyName, new MerossOnOffThingProperty(options)],
      [PowerConsumptionThingPropertyName, new MerossPowerConsumptionThingProperty(options)],
      [PowerConsumptionHistoryThingPropertyName, new MerossPowerConsumptionHistoryThingProperty(options)],
    ]);
  }
}
