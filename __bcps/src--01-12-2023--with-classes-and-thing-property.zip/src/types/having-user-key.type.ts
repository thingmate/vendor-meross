export type IUserKey = string;

export interface IHavingUserKey {
  readonly key: IUserKey;
}
