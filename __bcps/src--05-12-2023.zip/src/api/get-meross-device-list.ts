import { AsyncTask } from '@lirx/async-task';
import { MEROSS_DEVICE_LIST_URL } from './constants/meross-device-list-url.constant';
import { fetchMerossAPI, IFetchMerossAPIOptions } from './helpers/fetch-meross-api';

/* TYPES */

/**
 * The `data` interface to send when getting the list of devices.
 */
export interface IMerossDeviceListRequestDataJSON {
}

export interface IMerossDeviceListResponseDataDeviceChanelJSON {

}

export const enum MEROSS_DEVICE_ONLINE_STATUS {
  ONLINE = 1,
  OFFLINE = 2,
}

/**
 * The interface returned by this API representing a device.
 */
export interface IMerossDeviceListResponseDataDeviceJSON {
  readonly uuid: string;
  readonly onlineStatus: MEROSS_DEVICE_ONLINE_STATUS;
  readonly devName: string;
  readonly devIconId: string;
  readonly bindTime: number;
  readonly deviceType: string;
  readonly subType: string;
  readonly channels: readonly IMerossDeviceListResponseDataDeviceChanelJSON[];
  readonly region: string;
  readonly fmwareVersion: string;
  readonly hdwareVersion: string;
  readonly userDevIcon: string;
  readonly iconType: number;
  readonly cluster: number;
  readonly domain: string;
  readonly reservedDomain: string;
}

/**
 * The data returned by this API.
 */
export type IMerossDeviceListResponseDataJSON = IMerossDeviceListResponseDataDeviceJSON[];

/**
 * The options to get the list of devices.
 */
export interface IGetMerossDeviceListOptions extends Omit<IFetchMerossAPIOptions, 'data' | 'url' | 'token'>, Required<Pick<IFetchMerossAPIOptions, 'token'>> {
}

/* FUNCTION */

/**
 * Performs a http request to get the list of devices from the Meross cloud servers.
 */
export function getMerossDeviceList(
  {
    token,
    ...options
  }: IGetMerossDeviceListOptions,
): AsyncTask<IMerossDeviceListResponseDataJSON> {
  const data: IMerossDeviceListRequestDataJSON = {};

  return fetchMerossAPI<IMerossDeviceListResponseDataJSON>({
    ...options,
    url: MEROSS_DEVICE_LIST_URL,
    data,
    token,
  });
}
