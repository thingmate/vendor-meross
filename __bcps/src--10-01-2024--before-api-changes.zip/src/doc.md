#

https://github.com/arandall/meross/blob/main/doc/protocol.md
https://albertogeniola.github.io/MerossIot/meross-protocol.html
