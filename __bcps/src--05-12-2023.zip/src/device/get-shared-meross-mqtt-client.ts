import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  IInitMerossMqttClientOptions,
  IInitMerossMqttClientResult,
  initMerossMqttClient,
  DEFAULT_MEROSS_MQTT_HOSTNAME, DEFAULT_MEROSS_MQTT_PORT,
} from './init-meross-mqtt-client';

function forgeSharedMerossMqttClientKey(
  {
    hostname = DEFAULT_MEROSS_MQTT_HOSTNAME,
    port = DEFAULT_MEROSS_MQTT_PORT,
    userId,
    key,
  }: Omit<IInitMerossMqttClientOptions, 'abortable'>,
): string {
  return JSON.stringify([
    hostname,
    port,
    userId,
    key,
  ]);
}

const map = new Map<string, AsyncTask<IInitMerossMqttClientResult>>();

export function getSharedMerossMqttClient(
  {
    abortable,
    ...options
  }: IInitMerossMqttClientOptions,
): AsyncTask<IInitMerossMqttClientResult> {
  const key: string = forgeSharedMerossMqttClientKey(options);

  let result: AsyncTask<IInitMerossMqttClientResult> | undefined = map.get(key);

  if (result === void 0) {
    result = initMerossMqttClient({
      ...options,
      abortable: Abortable.never,
    });
    map.set(key, result);
  }

  return AsyncTask.switchAbortable(result, abortable);
}
