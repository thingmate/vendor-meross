import { IAsyncTaskInput } from '@lirx/async-task';
import { IPushSourceWithBackPressure, mapPushPipeWithBackPressure } from '@lirx/stream';
import { IMqttClientOnTrait, IStandardMqttPublishPacket } from '@thingmate/mqtt';
import { IHavingUserKey } from '../../../../types/user-key.type';

import { IGenericMerossPacket } from '../../meross-packet.type';
import { verifyMerossPacket } from '../verify-meross-packet';
import {
  getMerossAppUserIdSubscribeTopic,
  IGetMerossAppUserIdSubscribeTopicOptions,
} from './topics/get-meross-app-user-id-subscribe-topic';

export interface ICreateMqttMerossPUSHPacketListenerOptions extends //
  IGetMerossAppUserIdSubscribeTopicOptions,
  IHavingUserKey
//
{
  readonly client: IMqttClientOnTrait;
}

/**
 * Creates a `PushSourceWithBackPressure` listening for `PUSH` packet, and emitting them.
 */
export function createMqttMerossPUSHPacketListener(
  {
    client,
    userId,
    key,
  }: ICreateMqttMerossPUSHPacketListenerOptions,
): IPushSourceWithBackPressure<IGenericMerossPacket> {
  const appliancePushNotifications$ = client.on(
    getMerossAppUserIdSubscribeTopic({
      userId,
    }),
  );

  return mapPushPipeWithBackPressure(
    appliancePushNotifications$,
    (
      standardMqttPublishPacket: IStandardMqttPublishPacket,
    ): IAsyncTaskInput<IGenericMerossPacket> => {
      const merossResponsePacket: IGenericMerossPacket = JSON.parse(standardMqttPublishPacket.payload.toString());

      // TODO discard invalid packet instead of erroring stream
      if (merossResponsePacket.header.method === 'PUSH') {
        verifyMerossPacket({
          packet: merossResponsePacket,
          key,
        });
        return merossResponsePacket;
      } else {
        console.log(merossResponsePacket);
        throw new Error(`Expected PUSH packet`);
      }
    });
}
