import { Abortable } from '@lirx/async-task';
import { ThingProperty } from '@thingmate/wot-scripting-api';
import { IMerossThingDescription } from './type/meross-thing-description.type';

export interface IMerossDescriptionThingPropertyOptions {
  readonly description: IMerossThingDescription;
}

export class MerossDescriptionThingProperty extends ThingProperty<IMerossThingDescription> {
  constructor(
    {
      description,
    }: IMerossDescriptionThingPropertyOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): IMerossThingDescription => {
        return description;
      },
    });
  }
}
