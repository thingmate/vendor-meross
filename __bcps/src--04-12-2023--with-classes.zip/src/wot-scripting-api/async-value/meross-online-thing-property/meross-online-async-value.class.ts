import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  IDeviceOptionsForCreateAndSendMerossPacketAbility,
} from '../../../device/packet/abilities/shared/device-options-for-create-and-send-meross-packet-ability';
import { AsyncValue } from '@thingmate/wot-scripting-api';

export interface IMerossOnlineAsyncValueOptions {
  readonly deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
}

export class MerossOnlineAsyncValue extends AsyncValue<boolean> {
  constructor(
    {
      deviceOptions,
    }: IMerossOnlineAsyncValueOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): AsyncTask<boolean> => {
        // TODO
        return AsyncTask.success(true, abortable);
      },
    });
  }
}

