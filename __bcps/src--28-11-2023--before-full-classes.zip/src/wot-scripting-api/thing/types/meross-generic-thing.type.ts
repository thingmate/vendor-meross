import { IThing } from '@thingmate/wot-scripting-api';
import { IMerossThingDescription } from './meross-thing-description.type';

export type IMerossGenericThing = IThing<any, IMerossThingDescription>;
