import { Abortable, AsyncTask } from '@lirx/async-task';
import { IPowerConsumption, AsyncValue } from '@thingmate/wot-scripting-api';
import {
  getMerossApplianceControlElectricity,
  IMerossApplianceControlElectricityAbilityGETACKPayload,
} from '../../../device/packet/abilities/appliance-control-electricity/meross-appliance-control-electricity.type';
import {
  IDeviceOptionsForCreateAndSendMerossPacketAbility,
} from '../../../device/packet/abilities/shared/device-options-for-create-and-send-meross-packet-ability';

export interface IMerossPowerConsumptionAsyncValueOptions {
  readonly deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  readonly channel?: number;
}

export class MerossPowerConsumptionAsyncValue extends AsyncValue<IPowerConsumption> {
  constructor(
    {
      deviceOptions,
      channel = 0,
    }: IMerossPowerConsumptionAsyncValueOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): AsyncTask<IPowerConsumption> => {
        return getMerossApplianceControlElectricity(
          {
            ...deviceOptions,
            payload: {
              electricity: {
                channel,
              },
            },
            abortable,
          },
        )
          .successful((response: IMerossApplianceControlElectricityAbilityGETACKPayload): IPowerConsumption => {
            const {
              current,
              voltage,
              power,
            } = response.electricity;
            return {
              current: current / 1000,
              voltage: voltage / 10,
              power: power / 1000,
            };
          });
      },
    });
  }
}
