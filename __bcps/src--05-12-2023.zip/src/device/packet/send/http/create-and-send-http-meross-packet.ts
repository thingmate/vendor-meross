import { AsyncTask, IAsyncTaskConstraint } from '@lirx/async-task';
import { createMerossPacket, ICreateMerossPacketOptions } from '../../create/create-meross-packet';
import { ISendHttpMerossPacketOptions, sendHttpMerossPacket } from './send-http-meross-packet';

/**
 * @deprecated
 */
export interface ICreateAndSendHttpMerossPacketOptions<GPayload> extends //
  ICreateMerossPacketOptions<GPayload>,
  Omit<ISendHttpMerossPacketOptions, 'packet'>
//
{
}

/**
 * @deprecated
 */
export function createAndSendHttpMerossPacket<GRequestPayload, GResponsePayload extends IAsyncTaskConstraint<GResponsePayload>>(
  options: ICreateAndSendHttpMerossPacketOptions<GRequestPayload>,
): AsyncTask<GResponsePayload> {
  return sendHttpMerossPacket<GResponsePayload>({
    ...options,
    packet: createMerossPacket<GRequestPayload>(options),
  });
}


