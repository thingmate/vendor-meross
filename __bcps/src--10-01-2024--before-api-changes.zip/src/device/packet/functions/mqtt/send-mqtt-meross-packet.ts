import {
  Abortable,
  AbortableController,
  AsyncTask,
  IAbortableOptions,
  IAsyncTaskConstraint,
  IAsyncTaskErrorFunction,
  IAsyncTaskSuccessFunction,
} from '@lirx/async-task';
import { IPushSourceWithBackPressure } from '@lirx/stream';
import {
  IMinimalMqttClientObserveTrait,
  IMinimalMqttClientPublishTrait,
  IReadonlyMqttPacketPayload,
  IWebSocketMinimalMqttClientFromPool,
} from '@thingmate/mqtt';
import { IUrlRewriter } from '@thingmate/wot-scripting-api';
import { IAppId } from '../../../../types/app-id.type';
import { IDeviceId } from '../../../../types/device-id.type';
import { IUserId } from '../../../../types/user-id.type';
import { IUserKey } from '../../../../types/user-key.type';
import { IGenericMerossPacket } from '../../meross-packet.type';
import { verifyMerossPacket } from '../verify-meross-packet';
import { MerossMqttClientPool } from './meross-mqtt-client-pool.class';
import { getMerossAppUserIdAppIdSubscribeTopic } from './topics/get-meross-app-user-id-app-id-subscribe-topic';
import { getMerossApplianceDeviceIdSubscribeTopic } from './topics/get-meross-appliance-device-id-subscribe-topic';

const MEROSS_MQTT_CLIENT_POOL = new MerossMqttClientPool();

// IMerossMqttClientPoolOpenOptions

export interface ISendMqttMerossPacketOptions extends IAbortableOptions {
  // to open the connection
  readonly hostname?: string;
  readonly port?: number;
  readonly urlRewriter?: IUrlRewriter;

  readonly key: IUserKey;
  readonly userId: IUserId;
  readonly appId: IAppId;

  // to send to packet
  readonly deviceId: IDeviceId;
  readonly packet: IGenericMerossPacket;
}

/**
 * Sends a Meross Packet over mqtt.
 *
 * Returns the payload of the response.
 */
export function sendMqttMerossPacket<GResponsePayload extends IAsyncTaskConstraint<GResponsePayload>>(
  {
    // to open the connection
    hostname,
    port,
    urlRewriter,
    key,
    userId,
    appId,
    // to send to packet
    deviceId,
    packet,
    abortable,
  }: ISendMqttMerossPacketOptions,
): AsyncTask<GResponsePayload> {
  return MEROSS_MQTT_CLIENT_POOL.open({
    hostname,
    port,
    urlRewriter,
    key,
    userId,
    appId,
    abortable,
  })
    .successful((client: IWebSocketMinimalMqttClientFromPool, abortable: Abortable): AsyncTask<GResponsePayload> => {
      return sendMqttMerossPacketUsingMinimalMqttClient<GResponsePayload>({
        client,
        key,
        userId,
        appId,
        deviceId,
        packet,
      });
    });
}

/*---------*/

export interface ISendMqttMerossPacketUsingMinimalMqttClientOptions extends Record<string, any> {
  readonly client: IMinimalMqttClientPublishTrait & IMinimalMqttClientObserveTrait;
  readonly key: IUserKey;
  readonly userId: IUserId;
  readonly appId: IAppId;
  readonly deviceId: IDeviceId;
  readonly packet: IGenericMerossPacket;
}

export function sendMqttMerossPacketUsingMinimalMqttClient<GResponsePayload extends IAsyncTaskConstraint<GResponsePayload>>(
  {
    client,
    key,
    userId,
    appId,
    deviceId,
    packet,
    abortable,
  }: ISendMqttMerossPacketUsingMinimalMqttClientOptions,
): AsyncTask<GResponsePayload> {
  return new AsyncTask<GResponsePayload>((
    _success: IAsyncTaskSuccessFunction<GResponsePayload>,
    _error: IAsyncTaskErrorFunction,
    abortable: Abortable,
  ): void => {
    const controller: AbortableController = new AbortableController([abortable]);
    const localAbortable: Abortable = controller.abortable;

    const localAbort = (reason: any = 'Aborted'): void => {
      controller.abort(reason);
    };

    const success = (value: GResponsePayload): void => {
      localAbort();
      _success(value);
    };

    const error = (error: unknown): void => {
      localAbort();
      _error(error);
    };

    const clientResponse$: IPushSourceWithBackPressure<IReadonlyMqttPacketPayload> = client.observe(
      getMerossAppUserIdAppIdSubscribeTopic({
        userId,
        appId,
      }),
    );

    clientResponse$((
      payload: IReadonlyMqttPacketPayload,
    ): void => {
      const merossResponsePacket: IGenericMerossPacket = JSON.parse(payload.toString());

      if (merossResponsePacket.header.messageId === packet.header.messageId) {
        try {
          verifyMerossPacket({
            packet: merossResponsePacket,
            key,
          });
          // TODO ensure than packet is an ACK
          success(merossResponsePacket.payload);
        } catch (_error: unknown) {
          error(_error);
        }
      }
    }, localAbortable)
      .errored(error);

    client.publish(
      getMerossApplianceDeviceIdSubscribeTopic({ deviceId }),
      JSON.stringify(packet),
      localAbortable,
    )
      .errored(error);

  }, abortable);
}
