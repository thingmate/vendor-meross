import { Abortable, AsyncTask } from '@lirx/async-task';
import { mapPushPipeWithBackPressure } from '@lirx/stream';
import { IOnOff, AsyncValue, IAsyncValueObserveFunction } from '@thingmate/wot-scripting-api';
import {
  createMerossApplianceControlToggleXAbilityListener,
  getMerossApplianceControlToggleX,
  IMerossApplianceControlToggleXAbilityGETACKPayload,
  IMerossApplianceControlToggleXAbilityPUSHPayload,
  setMerossApplianceControlToggleX,
} from '../../../device/packet/abilities/appliance-control-toggle-x/meross-appliance-control-toggle-x.type';
import {
  IDeviceOptionsForCreateAndSendMerossPacketAbility,
} from '../../../device/packet/abilities/shared/device-options-for-create-and-send-meross-packet-ability';

import { merossToggleStateToOnOffState } from '../../shared/on-off-state/meross-toggle-state-to-on-off-state';
import { onOffStateToMerossToggleState } from '../../shared/on-off-state/on-off-state-to-meross-toggle-state';
import { IMerossDeviceListResponseDataDeviceJSON } from '../../../api/get-meross-device-list';

export interface IMerossOnOffAsyncValueOptions {
  readonly deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
  readonly channel?: number;
}

export class MerossOnOffAsyncValueFromDeviceOptions extends AsyncValue<IOnOff> {
  constructor(
    {
      deviceOptions,
      channel = 0,
    }: IMerossOnOffAsyncValueOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): AsyncTask<IOnOff> => {
        return getMerossApplianceControlToggleX({
          ...deviceOptions,
          payload: {
            togglex: {
              channel: channel,
            },
          },
          abortable,
        })
          .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
            return merossToggleStateToOnOffState(response.togglex.onoff);
          });
      },
      write: (
        value: IOnOff,
        abortable: Abortable,
      ): AsyncTask<void> => {
        return setMerossApplianceControlToggleX({
          ...deviceOptions,
          payload: {
            togglex: {
              channel: channel,
              onoff: onOffStateToMerossToggleState(value),
            },
          },
          abortable,
        });
      },
      observe: mapPushPipeWithBackPressure(
        createMerossApplianceControlToggleXAbilityListener(deviceOptions),
        (
          payload: IMerossApplianceControlToggleXAbilityPUSHPayload,
        ): IOnOff => {
          return merossToggleStateToOnOffState(payload.togglex[channel].onoff);
        },
      ) as IAsyncValueObserveFunction<IOnOff>,
    });
  }
}

export class MerossOnOffAsyncValueFromDeviceData extends AsyncValue<IOnOff> {
  constructor(
    {

    }: IMerossDeviceListResponseDataDeviceJSON,
  ) {
    super();
  }
}
