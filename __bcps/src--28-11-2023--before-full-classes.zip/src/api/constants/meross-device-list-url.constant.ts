import { MEROSS_URL } from './meross-url.constant';

export const MEROSS_DEVICE_LIST_URL = `${MEROSS_URL}/v1/Device/devList`;
