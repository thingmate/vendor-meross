export const MEROSS_SECRET = '23x17ahWarFH6w29';
