import { IMerossDeviceListResponseDataDeviceJSON } from '../../api/get-meross-device-list';
import { IMerossPacketManagerOptions, MerossPacketManager } from '../../device/packet/meross-packet-manager.class';
import { createMerossMss310SmartPlugThing, IMerossMss310SmartPlugThing } from './smart-plug/mss310/meross-mss310-smart-plug-thing';

export type IMerossThing =
  | IMerossMss310SmartPlugThing
  ;

export interface ICreateMerossThingOptions extends Omit<IMerossPacketManagerOptions, 'deviceId'> {
  readonly device: IMerossDeviceListResponseDataDeviceJSON;
}

export function createMerossThing(
  {
    mqtt,
    http,
    key,
    userId,
    appId,
    device,
  }: ICreateMerossThingOptions,
): IMerossThing {
  const manager = new MerossPacketManager({
    mqtt,
    http: {
      hostname: device.domain,
      ...http,
    },
    key,
    userId,
    appId,
    deviceId: device.uuid,
  });

  switch (device.deviceType) {
    case 'mss310':
      return createMerossMss310SmartPlugThing({
        manager,
        channel: 0,
      });
    default:
      throw new Error(`Unsupported type: ${device.deviceType}`);
  }
}
