import { Abortable, AsyncTask, IAbortableOptions } from '@lirx/async-task';
import {
  getMerossDeviceList,
  IGetMerossDeviceListOptions,
  IMerossDeviceListResponseDataDeviceJSON,
  IMerossDeviceListResponseDataJSON,
} from '../../api/get-meross-device-list';
import { IMerossLoginResponseDataJSON, IPerformMerossLoginOptions, performMerossLogin } from '../../api/perform-meross-login';
import { createMerossThing, ICreateMerossThingOptions, IMerossThing } from '../thing/meross-thing';

export interface IListMerossThingsOptions extends //
  Omit<IPerformMerossLoginOptions, 'urlRewriter' | 'abortable'>,
  Omit<IGetMerossDeviceListOptions, 'urlRewriter' | 'token' | 'abortable'>,
  Omit<ICreateMerossThingOptions, 'key' | 'userId' | 'device' | 'abortable'>,
  IAbortableOptions
//
{

}

export function listMerossThings(
  {
    email,
    password,
    mqtt,
    http: {
      urlRewriter: httpUrlRewriter,
      ...http
    } = {},
    appId,
    abortable,
  }: IListMerossThingsOptions,
): AsyncTask<IMerossThing[]> {
  return performMerossLogin({
    email,
    password,
    urlRewriter: httpUrlRewriter,
    abortable,
  })
    .successful((loginData: IMerossLoginResponseDataJSON, abortable: Abortable): AsyncTask<IMerossThing[]> => {
      return getMerossDeviceList({
        token: loginData.token,
        urlRewriter: httpUrlRewriter,
        abortable,
      })
        .successful((devices: IMerossDeviceListResponseDataJSON): IMerossThing[] => {
          return devices.map((device: IMerossDeviceListResponseDataDeviceJSON): IMerossThing => {
            return createMerossThing({
              mqtt,
              http: {
                ...http,
                urlRewriter: httpUrlRewriter,
              },
              key: loginData.key,
              userId: loginData.userid,
              appId,
              device,
            });
          });
        });
    });
}
