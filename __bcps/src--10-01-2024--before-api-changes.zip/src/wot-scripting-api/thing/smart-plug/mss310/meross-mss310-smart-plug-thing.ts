import { IHavingOnOffAsyncValue, OnOffAsyncValueName } from '@thingmate/wot-scripting-api';
import { createMerossOnOffAsyncValue, ICreateMerossOnOffAsyncValueOptions } from '../../../async-value/onoff/meross-on-off-async-value';

export interface IMerossMss310SmartPlugThing extends //
  IHavingOnOffAsyncValue
//
{

}

export interface ICreateMerossMss310SmartPlugThingOptions extends //
  ICreateMerossOnOffAsyncValueOptions
  //
{
}

export function createMerossMss310SmartPlugThing(
  options: ICreateMerossMss310SmartPlugThingOptions,
): IMerossMss310SmartPlugThing {
  return {
    [OnOffAsyncValueName]: createMerossOnOffAsyncValue(options),
  };
}

/*-----------*/

// export interface IMerossMss310SmartPlugThingOptions extends //
//   IMerossDescriptionThingPropertyOptions,
//   IMerossOnlineThingPropertyOptions,
//   IMerossOnOffThingPropertyOptions,
//   IMerossPowerConsumptionThingPropertyOptions,
//   IMerossPowerConsumptionHistoryThingPropertyOptions
// //
// {
// }
//
// // export type IMerossSmartPlugThing = ISmartPlugThing<IMerossThingDescription>;
//
// export class MerossMss310SmartPlugThing extends Thing<ISmartPlugProperties> implements ISmartPlugThing {
//   constructor(
//     options: IMerossMss310SmartPlugThingOptions,
//   ) {
//     super([
//       [DescriptionThingPropertyName, new MerossDescriptionThingProperty(options)],
//       [OnlineThingPropertyName, new MerossOnlineThingProperty(options)],
//       [OnOffThingPropertyName, new MerossOnOffThingProperty(options)],
//       [PowerConsumptionThingPropertyName, new MerossPowerConsumptionThingProperty(options)],
//       [PowerConsumptionHistoryThingPropertyName, new MerossPowerConsumptionHistoryThingProperty(options)],
//     ]);
//   }
// }
