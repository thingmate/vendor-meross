import {
  ISmartPlugThing,
  Thing,
  OnlineThingPropertyName,
  OnOffThingPropertyName,
  PowerConsumptionThingPropertyName,
  PowerConsumptionHistoryThingPropertyName,
  DescriptionThingPropertyName,
  ISmartPlugProperties,
} from '@thingmate/wot-scripting-api';
import {
  IMerossOnOffThingPropertyOptions,
  MerossOnOffThingProperty,
} from '../../../thing-property/meross-on-off-thing-property/meross-on-off-thing-property.class';
import {
  IMerossOnlineThingPropertyOptions,
  MerossOnlineThingProperty,
} from '../../../thing-property/meross-online-thing-property/meross-online-thing-property.class';
import {
  IMerossPowerConsumptionHistoryThingPropertyOptions,
  MerossPowerConsumptionHistoryThingProperty,
} from '../../../thing-property/meross-power-consumption-history-thing-property/meross-power-consumption-history-thing-property.class';
import {
  IMerossPowerConsumptionThingPropertyOptions,
  MerossPowerConsumptionThingProperty,
} from '../../../thing-property/meross-power-consumption-thing-property/meross-power-consumption-thing-property.class';
import {
  MerossDescriptionThingProperty,
  IMerossDescriptionThingPropertyOptions,
} from '../../../thing-property/meross-description-thing-property/meross-description-thing-property.class';

export interface IMerossMss310SmartPlugThingOptions extends //
  IMerossDescriptionThingPropertyOptions,
  IMerossOnlineThingPropertyOptions,
  IMerossOnOffThingPropertyOptions,
  IMerossPowerConsumptionThingPropertyOptions,
  IMerossPowerConsumptionHistoryThingPropertyOptions
//
{
}

// export type IMerossSmartPlugThing = ISmartPlugThing<IMerossThingDescription>;

export class MerossMss310SmartPlugThing extends Thing<ISmartPlugProperties> implements ISmartPlugThing {
  constructor(
    options: IMerossMss310SmartPlugThingOptions,
  ) {
    super([
      [DescriptionThingPropertyName, new MerossDescriptionThingProperty(options)],
      [OnlineThingPropertyName, new MerossOnlineThingProperty(options)],
      [OnOffThingPropertyName, new MerossOnOffThingProperty(options)],
      [PowerConsumptionThingPropertyName, new MerossPowerConsumptionThingProperty(options)],
      [PowerConsumptionHistoryThingPropertyName, new MerossPowerConsumptionHistoryThingProperty(options)],
    ]);
  }
}
