#

https://github.com/arandall/meross/blob/main/doc/protocol.md

