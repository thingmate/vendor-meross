import { IThingDescription } from '@thingmate/wot-scripting-api';

export interface IMerossThingDescription extends IThingDescription {
  readonly id: string;
  readonly firmwareVersion: string;
  readonly hardwareVersion: string;
  readonly deviceType: string;
  readonly online: boolean;
}

