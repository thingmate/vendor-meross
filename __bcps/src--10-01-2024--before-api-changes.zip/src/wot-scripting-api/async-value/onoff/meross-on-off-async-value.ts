import { Abortable, AsyncTask } from '@lirx/async-task';
import { IAsyncValue, IAsyncValueReadFunction, IAsyncValueWriteFunction, IOnOff } from '@thingmate/wot-scripting-api';
import {
  IMerossApplianceControlToggleXAbilityGETACKPayload,
  IMerossApplianceControlToggleXAbilityGETPayload,
  IMerossApplianceControlToggleXAbilitySETACKPayload,
  IMerossApplianceControlToggleXAbilitySETPayload,
  MEROSS_APPLIANCE_CONTROL_TOGGLE_X_ABILITY_NAME,
} from '../../../device/packet/abilities/appliance-control-toggle-x/meross-appliance-control-toggle-x.type';
import { MerossPacketManager } from '../../../device/packet/meross-packet-manager.class';

import { merossToggleStateToOnOffState } from '../../shared/on-off-state/meross-toggle-state-to-on-off-state';
import { onOffStateToMerossToggleState } from '../../shared/on-off-state/on-off-state-to-meross-toggle-state';

/*----------*/

export interface ICreateMerossOnOffAsyncValueReadFunctionOptions {
  readonly manager: MerossPacketManager;
  readonly channel?: number;
}

export function createMerossOnOffAsyncValueReadFunction(
  {
    channel = 0,
    manager,
  }: ICreateMerossOnOffAsyncValueReadFunctionOptions,
): IAsyncValueReadFunction<IOnOff> {
  return (
    abortable: Abortable,
  ): AsyncTask<IOnOff> => {
    return manager.query<IMerossApplianceControlToggleXAbilityGETACKPayload>({
      method: 'GET',
      namespace: MEROSS_APPLIANCE_CONTROL_TOGGLE_X_ABILITY_NAME,
      payload: {
        togglex: {
          channel,
        },
      } satisfies IMerossApplianceControlToggleXAbilityGETPayload,
      abortable,
    })
      .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
        return merossToggleStateToOnOffState(response.togglex.onoff);
      });
  };
}

export interface ICreateMerossOnOffAsyncValueWriteFunctionOptions {
  readonly manager: MerossPacketManager;
  readonly channel?: number;
}

export function createMerossOnOffAsyncValueWriteFunction(
  {
    channel = 0,
    manager,
  }: ICreateMerossOnOffAsyncValueWriteFunctionOptions,
): IAsyncValueWriteFunction<IOnOff> {
  return (
    value: IOnOff,
    abortable: Abortable,
  ): AsyncTask<void> => {
    return manager.query<IMerossApplianceControlToggleXAbilitySETACKPayload>({
      method: 'SET',
      namespace: MEROSS_APPLIANCE_CONTROL_TOGGLE_X_ABILITY_NAME,
      payload: {
        togglex: {
          channel,
          onoff: onOffStateToMerossToggleState(value),
        },
      } satisfies IMerossApplianceControlToggleXAbilitySETPayload,
      abortable,
    });
  };
}

/*----------*/

// observe: mapPushPipeWithBackPressure(
//   createMerossApplianceControlToggleXAbilityListener(options),
//   (
//     payload: IMerossApplianceControlToggleXAbilityPUSHPayload,
//   ): IOnOff => {
//     return merossToggleStateToOnOffState(payload.togglex[channel].onoff);
//   },
// ) as IAsyncValueObserveFunction<IOnOff>,

/*----------*/

export interface ICreateMerossOnOffAsyncValueOptions extends //
  ICreateMerossOnOffAsyncValueReadFunctionOptions,
  ICreateMerossOnOffAsyncValueWriteFunctionOptions
  //
{
}

export function createMerossOnOffAsyncValue(
  options: ICreateMerossOnOffAsyncValueOptions,
): IAsyncValue<IOnOff> {
  return {
    read: createMerossOnOffAsyncValueReadFunction(options),
    write: createMerossOnOffAsyncValueWriteFunction(options),
    observe: void 0, // TODO
  };
}

