export type IBooleanAsNumber =
  | 0 // false
  | 1 // true
  ;

