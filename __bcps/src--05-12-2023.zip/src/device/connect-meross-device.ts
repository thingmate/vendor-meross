import { Abortable, AsyncTask } from '@lirx/async-task';
import { getSharedMerossMqttClient } from './get-shared-meross-mqtt-client';
import { IInitMerossMqttClientOptions, IInitMerossMqttClientResult } from './init-meross-mqtt-client';
import {
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
} from './packet/abilities/shared/create-and-send-meross-packet-options-for-generic-ability-without-payload.type';
import {
  IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions,
  prepareDeviceOptionsForCreateAndSendMerossPacketAbility,
} from './packet/prepare-device-options-for-create-and-send-meross-packet-ability';

export interface IConnectMerossDeviceOptions extends //
  IInitMerossMqttClientOptions,
  Omit<IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions, keyof IInitMerossMqttClientResult | keyof IInitMerossMqttClientOptions>
//
{

}

/**
 * TODO
 * @deprecated
 */
export function connectMerossDevice(
  {
    deviceId,
    timeout,
    retry,
    ...options
  }: IConnectMerossDeviceOptions,
): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> {
  return getSharedMerossMqttClient(options)
    .successful((clientResult: IInitMerossMqttClientResult, abortable: Abortable): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> => {
      return prepareDeviceOptionsForCreateAndSendMerossPacketAbility({
        ...clientResult,
        deviceId,
        timeout,
        retry,
        abortable,
      });
    });
}
