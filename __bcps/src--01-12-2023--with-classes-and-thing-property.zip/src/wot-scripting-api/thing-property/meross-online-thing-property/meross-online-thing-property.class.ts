import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  IDeviceOptionsForCreateAndSendMerossPacketAbility,
} from '../../../device/packet/abilities/shared/device-options-for-create-and-send-meross-packet-ability';
import { ThingProperty } from '@thingmate/wot-scripting-api';

export interface IMerossOnlineThingPropertyOptions {
  readonly deviceOptions: IDeviceOptionsForCreateAndSendMerossPacketAbility;
}

export class MerossOnlineThingProperty extends ThingProperty<boolean> {
  constructor(
    {
      deviceOptions,
    }: IMerossOnlineThingPropertyOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): AsyncTask<boolean> => {
        // TODO
        return AsyncTask.success(true, abortable);
      },
    });
  }
}

