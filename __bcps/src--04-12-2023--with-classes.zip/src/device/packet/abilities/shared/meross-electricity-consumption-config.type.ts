export interface IMerossElectricityConsumptionConfig {
  readonly voltageRatio: number;
  readonly electricityRatio: number;
}
