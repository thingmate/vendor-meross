export type IAppId = string;

export interface IHavingAppId {
  readonly appId: IAppId;
}
