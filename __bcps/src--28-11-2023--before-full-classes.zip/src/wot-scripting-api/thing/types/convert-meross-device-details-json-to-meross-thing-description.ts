import { IMerossDeviceListResponseDataDeviceJSON, MEROSS_DEVICE_ONLINE_STATUS } from '../../../api/get-meross-device-list';
import { IMerossThingDescription } from './meross-thing-description.type';

export function convertMerossDeviceDetailsJSONToMerossThingDescription(
  device: IMerossDeviceListResponseDataDeviceJSON,
): IMerossThingDescription {
  return {
    id: device.uuid,
    title: device.devName,
    firmwareVersion: device.fmwareVersion,
    hardwareVersion: device.hdwareVersion,
    deviceType: device.deviceType,
    online: (device.onlineStatus === MEROSS_DEVICE_ONLINE_STATUS.ONLINE),
  };
}
