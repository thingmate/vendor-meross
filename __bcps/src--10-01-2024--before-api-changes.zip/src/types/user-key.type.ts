export type IUserKey = string;

/**
 * @deprecated
 */
export interface IHavingUserKey {
  readonly key: IUserKey;
}
