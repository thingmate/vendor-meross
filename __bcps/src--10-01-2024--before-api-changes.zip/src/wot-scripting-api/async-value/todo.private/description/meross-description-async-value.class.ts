import { Abortable } from '@lirx/async-task';
import { AsyncValue } from '@thingmate/wot-scripting-api';
import { IMerossThingDescription } from './type/meross-thing-description.type';

export interface IMerossDescriptionAsyncValueOptions {
  readonly description: IMerossThingDescription;
}

export class MerossDescriptionAsyncValue extends AsyncValue<IMerossThingDescription> {
  constructor(
    {
      description,
    }: IMerossDescriptionAsyncValueOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): IMerossThingDescription => {
        return description;
      },
    });
  }
}
