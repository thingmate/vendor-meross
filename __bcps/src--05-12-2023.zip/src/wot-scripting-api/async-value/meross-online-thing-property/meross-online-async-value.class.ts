import { Abortable, AsyncTask } from '@lirx/async-task';
import {
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
} from '../../../device/packet/abilities/shared/create-and-send-meross-packet-options-for-generic-ability-without-payload.type';
import { AsyncValue } from '@thingmate/wot-scripting-api';

export interface IMerossOnlineAsyncValueOptions {
  readonly deviceOptions: ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload;
}

export class MerossOnlineAsyncValue extends AsyncValue<boolean> {
  constructor(
    {
      deviceOptions,
    }: IMerossOnlineAsyncValueOptions,
  ) {
    super({
      read: (
        abortable: Abortable,
      ): AsyncTask<boolean> => {
        // TODO
        return AsyncTask.success(true, abortable);
      },
    });
  }
}

