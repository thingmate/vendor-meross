export type IDeviceId = string;

export interface IHavingDeviceId {
  readonly deviceId: IDeviceId;
}
