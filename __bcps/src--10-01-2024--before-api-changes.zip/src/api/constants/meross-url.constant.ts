export const MEROSS_URL = 'https://iotx.meross.com';
