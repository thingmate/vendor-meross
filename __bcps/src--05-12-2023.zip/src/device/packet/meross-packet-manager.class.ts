

export class MerossPacketManager {

  static createPacket(): any {

  }

  constructor() {
  }



  sendHttp(): any {

  }
}
