export type IDeviceId = string;

/**
 * @deprecated
 */
export interface IHavingDeviceId {
  readonly deviceId: IDeviceId;
}
