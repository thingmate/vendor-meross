import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { IUrlRewriter, NO_URL_REWRITE } from '@thingmate/wot-scripting-api';
import { MEROSS_LOGIN_URL } from './constants/meross-login-url.constant';
import { fetchMerossAPI } from './helpers/fetch-meross-api';

/* TYPES */

export interface IMerossLoginRequestDataMobileInfoJSON {
  readonly deviceModel: string;
  readonly mobileOsVersion: string;
  readonly mobileOs: string;
  readonly uuid: string;
  readonly carrier: string;
}

/**
 * The `data` interface to send when login.
 */
export interface IMerossLoginRequestDataJSON {
  readonly email: string;
  readonly password: string;
  readonly mobileInfo: IMerossLoginRequestDataMobileInfoJSON; // INFO: seems optional
}

/**
 * The response sent by the Meross cloud servers when login.
 *
 * These properties are used later, when connection to the MQTT server, and when sending packets.
 */
export interface IMerossLoginResponseDataJSON {
  readonly userid: string;
  readonly email: string;
  readonly token: string;
  readonly key: string;
}

/**
 * The options to login.
 */
export interface IPerformMerossLoginOptions extends IAbortableOptions {
  readonly email: string;
  readonly password: string;
  readonly urlRewriter?: IUrlRewriter;
}

/* FUNCTION */

/**
 * Performs a http request to login on the Meross cloud servers.
 *
 * WARN: Meross highly limits the API calls, so this function's result should be cached.
 */
export function performMerossLogin(
  {
    email,
    password,
    urlRewriter = NO_URL_REWRITE,
    abortable,
  }: IPerformMerossLoginOptions,
): AsyncTask<IMerossLoginResponseDataJSON> {
  const logIdentifier = '0b11b194f83724b614a6975b112f63cee2f098-8125-40c7-a280-5115913d9887';

  const data: IMerossLoginRequestDataJSON = {
    email,
    password,
    // INFO: seems optional
    mobileInfo: {
      deviceModel: '',
      mobileOsVersion: '',
      mobileOs: 'linux',
      uuid: logIdentifier,
      carrier: '',
    },
  };

  return fetchMerossAPI<IMerossLoginResponseDataJSON>({
    url: urlRewriter(MEROSS_LOGIN_URL),
    data,
    abortable,
  });
}
