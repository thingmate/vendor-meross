export const MEROSS_URL = 'https://iot.meross.com';
