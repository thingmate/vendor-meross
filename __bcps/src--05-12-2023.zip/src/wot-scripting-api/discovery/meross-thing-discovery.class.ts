import {
  Abortable,
  AsyncTask,
  createAsyncTaskIterator,
  IAsyncTaskIteratorAwaitFunction,
  IAsyncTaskIterator,
  IAbortableOptions,
} from '@lirx/async-task';
import { ThingDiscovery, Thing } from '@thingmate/wot-scripting-api';
import {
  getMerossDeviceList,
  IMerossDeviceListResponseDataDeviceJSON,
  IMerossDeviceListResponseDataJSON,
  MEROSS_DEVICE_ONLINE_STATUS,
} from '../../api/get-meross-device-list';
import { IMerossLoginResponseDataJSON, IPerformMerossLoginOptions, performMerossLoginCached } from '../../api/perform-meross-login';
import { connectMerossDevice, IConnectMerossDeviceOptions } from '../../device/connect-meross-device';
import {
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
} from '../../device/packet/abilities/shared/create-and-send-meross-packet-options-for-generic-ability-without-payload.type';
import { MerossMss310SmartPlugThing } from '../thing/smart-plug/mss310/meross-mss310-smart-plug-thing.class';
import {
  convertMerossDeviceDetailsJSONToMerossThingDescription,
} from '../async-value/description/functions/convert-meross-device-details-json-to-meross-thing-description';

export interface IMerossThingDiscoveryOptions extends //
  Omit<IPerformMerossLoginOptions, 'abortable'>,
  Omit<IConnectMerossDeviceOptions, 'hostname' | 'deviceId' | 'userId' | 'key' | 'abortable' | 'port'>,
  IAbortableOptions
//
{
}

export function listMerossThings(
  options: IMerossThingDiscoveryOptions,
): AsyncTask<any[]> {
  return performMerossLoginCached(options)
    .successful((loginData: IMerossLoginResponseDataJSON, abortable: Abortable): AsyncTask<IMerossDeviceListResponseDataJSON> => {
      return getMerossDeviceList({
        token: loginData.token,
        fetch: options.fetch,
        abortable,
      })
        .successful((devices: IMerossDeviceListResponseDataJSON) => {

        });
    });
}

export function merossThingDiscoveryAsyncTaskGenerator(
  options: IMerossThingDiscoveryOptions,
): IAsyncTaskIterator<Thing<any>, any, any> {
  return createAsyncTaskIterator(async function* (
    __await__: IAsyncTaskIteratorAwaitFunction,
  ): AsyncGenerator<Thing<any>, any, any> {
    const loginData: IMerossLoginResponseDataJSON = await __await__((abortable: Abortable): AsyncTask<IMerossLoginResponseDataJSON> => {
      return performMerossLoginCached({
        ...options,
        abortable,
      });
    });

    const devices: IMerossDeviceListResponseDataJSON = await __await__((abortable: Abortable): AsyncTask<IMerossDeviceListResponseDataJSON> => {
      return getMerossDeviceList({
        token: loginData.token,
        fetch: options.fetch,
        abortable,
      });
    });

    for (let i = 0, l = devices.length; i < l; i++) {
      const device: IMerossDeviceListResponseDataDeviceJSON = devices[i];

      if (device.onlineStatus === MEROSS_DEVICE_ONLINE_STATUS.ONLINE) {
        const deviceOptions: ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload = await __await__((abortable: Abortable): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> => {
          return connectMerossDevice({
            hostname: device.domain,
            deviceId: device.uuid,
            userId: loginData.userid,
            key: loginData.key,
            openWebSocketMqttClient: options.openWebSocketMqttClient,
            retry: 2,
            abortable,
          });
        });

        switch (device.deviceType) {
          case 'mss310':
            yield new MerossMss310SmartPlugThing({
              description: convertMerossDeviceDetailsJSONToMerossThingDescription(device),
              deviceOptions,
            });
          default:
            throw new Error(`Unsupported type: ${device.deviceType}`);
        }
      }
    }
  });
}

export class MerossThingDiscovery extends ThingDiscovery<Thing<any>> {
  constructor(
    options: IMerossThingDiscoveryOptions,
  ) {
    super(merossThingDiscoveryAsyncTaskGenerator(options));
  }
}


