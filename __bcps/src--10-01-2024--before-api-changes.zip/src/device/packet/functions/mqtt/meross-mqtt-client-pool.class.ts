import { md5 } from '@lifaon/md5';
import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { IMqttProtocolVersion, IWebSocketMinimalMqttClientFromPool, WebSocketMinimalMqttClientPool } from '@thingmate/mqtt';
import { IUrlRewriter, NO_URL_REWRITE } from '@thingmate/wot-scripting-api';
import { IAppId } from '../../../../types/app-id.type';
import { IUserId } from '../../../../types/user-id.type';
import { IUserKey } from '../../../../types/user-key.type';

export const DEFAULT_MEROSS_MQTT_HOSTNAME = 'eu-iot.meross.com';
export const DEFAULT_MEROSS_MQTT_PORT = 2001;

export interface IMerossMqttClientPoolOpenOptions extends IAbortableOptions {
  readonly hostname?: string;
  readonly port?: number;
  readonly urlRewriter?: IUrlRewriter;
  readonly key: IUserKey;
  readonly userId: IUserId;
  readonly appId: IAppId;
}

export class MerossMqttClientPool {
  readonly #pool: WebSocketMinimalMqttClientPool;

  constructor() {
    this.#pool = new WebSocketMinimalMqttClientPool();
  }

  open(
    {
      hostname = DEFAULT_MEROSS_MQTT_HOSTNAME,
      port = DEFAULT_MEROSS_MQTT_PORT,
      urlRewriter = NO_URL_REWRITE,
      key,
      userId,
      appId,
      abortable,
    }: IMerossMqttClientPoolOpenOptions,
  ): AsyncTask<IWebSocketMinimalMqttClientFromPool> {
    const url: URL = new URL(urlRewriter(`wss://${hostname}:${port}/mqtt`));
    const protocolVersion: IMqttProtocolVersion = 5;
    const keepalive: number = 30;
    // const appId: string = md5(crypto.randomUUID());
    const clientId: string = `app:${appId}`;
    const username: string = userId;
    const password: string = md5(userId + key);

    return this.#pool.open({
      url,
      protocolVersion,
      keepalive,
      clientId,
      username,
      password,
      abortable,
    })/*
      .successful((client: IWebSocketMqttClientFromPool, abortable: Abortable): AsyncTask<IWebSocketMqttClientFromPool> => {
        return WebSocketMqttClientPool.hash(
          [
            userId,
            appId
          ],
          abortable,
        )
          .successful((key: string, abortable: Abortable): AsyncTask<IWebSocketMqttClientFromPool> => {
            return AsyncTask.all([
              (abortable: Abortable): AsyncTask<any> => {
                return client.subscribe({
                  topic: getMerossAppUserIdAppIdSubscribeTopic({
                    userId,
                    appId,
                  }),
                  abortable,
                });
              },
              (abortable: Abortable): AsyncTask<any> => {
                return client.subscribe({
                  topic: getMerossAppUserIdSubscribeTopic({
                    userId,
                  }),
                  abortable,
                });
              },
            ], abortable);
          })

      })*/;
  }
}
