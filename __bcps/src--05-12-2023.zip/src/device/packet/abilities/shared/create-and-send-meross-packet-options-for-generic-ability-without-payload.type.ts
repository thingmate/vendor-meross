import { ICreateAndSendMerossPacketOptionsForAbility } from './create-and-send-meross-packet-options-for-ability.type';

export type ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload =
  Omit<ICreateAndSendMerossPacketOptionsForAbility<any>, 'payload' | 'abortable'>
  ;
