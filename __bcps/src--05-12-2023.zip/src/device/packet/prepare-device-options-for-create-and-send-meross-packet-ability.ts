import { Abortable, AsyncTask, IAbortableOptions, asyncRetry } from '@lirx/async-task';
import {
  IMerossApplianceSystemFirmwareAbilityGETACKPayload,
  IMerossApplianceSystemFirmwareAbilityGETPayload,
  MEROSS_APPLIANCE_SYSTEM_FIRMWARE_ABILITY_NAME,
} from './abilities/appliance-system-firmware/meross-appliance-system-firmware.type';
import {
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
} from './abilities/shared/create-and-send-meross-packet-options-for-generic-ability-without-payload.type';
import { createAndSendHttpMerossPacketWithTimeout } from './send/http/create-and-send-http-meross-packet-with-timeout';
import { ICreateAndSendMqttMerossPacketOptions } from './send/mqtt/create-and-send-mqtt-meross-packet';
import { createAndSendMqttMerossPacketWithTimeout } from './send/mqtt/create-and-send-mqtt-meross-packet-with-timeout';

export interface IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions extends //
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
  IAbortableOptions
  //
{
  readonly retry?: number;
}

/**
 * Generates the optimal options to provide to the `createAndSendMerossPacket` function.
 *
 * It tries to connect to the device using mqtt to retrieve the device ip, and then tries to connect using http.
 * Then it infers the best communication protocol.
 *
 * @deprecated
 */
export function prepareDeviceOptionsForCreateAndSendMerossPacketAbility(
  {
    retry = 1,
    abortable,
    ...options
  }: IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions,
): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> {
  const _options: Omit<ICreateAndSendMqttMerossPacketOptions<IMerossApplianceSystemFirmwareAbilityGETPayload>, 'abortable'> = {
    ...options,
    method: 'GET',
    namespace: MEROSS_APPLIANCE_SYSTEM_FIRMWARE_ABILITY_NAME,
    payload: {},
  };

  return asyncRetry((abortable: Abortable): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> => {
    return createAndSendMqttMerossPacketWithTimeout<IMerossApplianceSystemFirmwareAbilityGETPayload, IMerossApplianceSystemFirmwareAbilityGETACKPayload>({
      ..._options,
      abortable,
    })
      .successful((
        data: IMerossApplianceSystemFirmwareAbilityGETACKPayload,
        abortable: Abortable,
      ): AsyncTask<ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload> => {
        const hostname: string = data.firmware.innerIp;

        return createAndSendHttpMerossPacketWithTimeout<IMerossApplianceSystemFirmwareAbilityGETPayload, IMerossApplianceSystemFirmwareAbilityGETACKPayload>({
          ..._options,
          hostname,
          abortable,
        })
          .then(
            (): ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload => {
              return {
                ...options,
                hostname,
              };
            },
            (): ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload => {
              return options;
            },
          );
      });
  }, retry, abortable);
}
