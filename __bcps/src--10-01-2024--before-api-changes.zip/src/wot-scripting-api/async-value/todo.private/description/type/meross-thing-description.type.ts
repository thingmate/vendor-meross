
export interface IMerossThingDescription {
  readonly id: string;
  readonly firmwareVersion: string;
  readonly hardwareVersion: string;
  readonly deviceType: string;
  readonly online: boolean;
}

