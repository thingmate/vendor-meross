import { Abortable, AsyncTask } from '@lirx/async-task';
import { mapPushPipeWithBackPressure } from '@lirx/stream';
import { IOnOff, IAsyncValueObserveFunction, IOnOffAsyncValue } from '@thingmate/wot-scripting-api';
import { IAsyncValueReadFunction } from '@thingmate/wot-scripting-api';
import {
  createMerossApplianceControlToggleXAbilityListener,
  getMerossApplianceControlToggleX,
  IMerossApplianceControlToggleXAbilityGETACKPayload,
  IMerossApplianceControlToggleXAbilityPUSHPayload,
  setMerossApplianceControlToggleX,
} from '../../../device/packet/abilities/appliance-control-toggle-x/meross-appliance-control-toggle-x.type';
import {
  ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload,
} from '../../../device/packet/abilities/shared/create-and-send-meross-packet-options-for-generic-ability-without-payload.type';

import { merossToggleStateToOnOffState } from '../../shared/on-off-state/meross-toggle-state-to-on-off-state';
import { onOffStateToMerossToggleState } from '../../shared/on-off-state/on-off-state-to-meross-toggle-state';
import { IMerossDeviceListResponseDataDeviceJSON } from '../../../api/get-meross-device-list';
import { getSharedMerossMqttClient } from '../../../device/get-shared-meross-mqtt-client';
import { IInitMerossMqttClientOptions, IInitMerossMqttClientResult } from '../../../device/init-meross-mqtt-client';
import {
  IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions
} from '../../../device/packet/prepare-device-options-for-create-and-send-meross-packet-ability';


/*----------*/

export interface ICreateMerossOnOffAsyncValueReadFunctionOptions {

}

export function createMerossOnOffAsyncValueReadFunction(
  {
    channel = 0,
    ...options
  }: ICreateMerossOnOffAsyncValueReadFunctionOptions,
): IAsyncValueReadFunction<IOnOff> {
  return (
    abortable: Abortable,
  ): AsyncTask<IOnOff> => {
    return getMerossApplianceControlToggleX({
      ...options,
      payload: {
        togglex: {
          channel,
        },
      },
      abortable,
    })
      .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
        return merossToggleStateToOnOffState(response.togglex.onoff);
      });
  }
}

// export function createMerossOnOffAsyncValueReadFunction(
//   {
//     channel = 0,
//     ...options
//   }: ICreateMerossOnOffAsyncValueFromDeviceOptionsOptions,
// ): IAsyncValueReadFunction<IOnOff> {
//   return (
//     abortable: Abortable,
//   ): AsyncTask<IOnOff> => {
//     return getMerossApplianceControlToggleX({
//       ...options,
//       payload: {
//         togglex: {
//           channel,
//         },
//       },
//       abortable,
//     })
//       .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
//         return merossToggleStateToOnOffState(response.togglex.onoff);
//       });
//   }
// }

/*----------*/

export interface ICreateMerossOnOffAsyncValueFromDeviceOptionsOptions extends ICreateAndSendMerossPacketOptionsForGenericAbilityWithoutPayload {
  readonly channel?: number;
}

export function createMerossOnOffAsyncValueFromDeviceOptions(
  {
    channel = 0,
    ...options
  }: ICreateMerossOnOffAsyncValueFromDeviceOptionsOptions,
): IOnOffAsyncValue {
  return {
    read: (
      abortable: Abortable,
    ): AsyncTask<IOnOff> => {
      return getMerossApplianceControlToggleX({
        ...options,
        payload: {
          togglex: {
            channel: channel,
          },
        },
        abortable,
      })
        .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
          return merossToggleStateToOnOffState(response.togglex.onoff);
        });
    },
    write: (
      value: IOnOff,
      abortable: Abortable,
    ): AsyncTask<void> => {
      return setMerossApplianceControlToggleX({
        ...options,
        payload: {
          togglex: {
            channel: channel,
            onoff: onOffStateToMerossToggleState(value),
          },
        },
        abortable,
      });
    },
    observe: mapPushPipeWithBackPressure(
      createMerossApplianceControlToggleXAbilityListener(options),
      (
        payload: IMerossApplianceControlToggleXAbilityPUSHPayload,
      ): IOnOff => {
        return merossToggleStateToOnOffState(payload.togglex[channel].onoff);
      },
    ) as IAsyncValueObserveFunction<IOnOff>,
  };
}

/*--*/

export interface ICreateMerossOnOffAsyncValueFromDeviceDataOptions extends //
  IInitMerossMqttClientOptions,
  Omit<IPrepareDeviceOptionsForCreateAndSendMerossPacketAbilityOptions, keyof IInitMerossMqttClientResult | keyof IInitMerossMqttClientOptions>,
  Omit<ICreateMerossOnOffAsyncValueFromDeviceOptionsOptions, 'deviceOptions'>
//
{
}

// TODO continue here

export function createMerossOnOffAsyncValueFromDeviceData(
  options: ICreateMerossOnOffAsyncValueFromDeviceDataOptions,
): IOnOffAsyncValue {
  const a = (
    abortable: Abortable,
  ): AsyncTask<any> => {
    return getSharedMerossMqttClient({
      ...options,
      abortable,
    })
      .successful((result: IInitMerossMqttClientResult) => {
        return createMerossOnOffAsyncValueFromDeviceOptions({
          deviceOptions: {
            ...options,
            ...result,

          },
          channel: 1,
        });
      });
  };

  return {
    read: (
      abortable: Abortable,
    ): AsyncTask<IOnOff> => {
      return getMerossApplianceControlToggleX({
        ...deviceOptions,
        payload: {
          togglex: {
            channel: channel,
          },
        },
        abortable,
      })
        .successful((response: IMerossApplianceControlToggleXAbilityGETACKPayload): IOnOff => {
          return merossToggleStateToOnOffState(response.togglex.onoff);
        });
    },
    write: (
      value: IOnOff,
      abortable: Abortable,
    ): AsyncTask<void> => {
      return setMerossApplianceControlToggleX({
        ...deviceOptions,
        payload: {
          togglex: {
            channel: channel,
            onoff: onOffStateToMerossToggleState(value),
          },
        },
        abortable,
      });
    },
    observe: mapPushPipeWithBackPressure(
      createMerossApplianceControlToggleXAbilityListener(deviceOptions),
      (
        payload: IMerossApplianceControlToggleXAbilityPUSHPayload,
      ): IOnOff => {
        return merossToggleStateToOnOffState(payload.togglex[channel].onoff);
      },
    ) as IAsyncValueObserveFunction<IOnOff>,
  };
}

export class MerossOnOffAsyncValueFromDeviceData extends AsyncValue<IOnOff> {
  constructor(
    {}: IMerossDeviceListResponseDataDeviceJSON,
  ) {
    super();
  }
}
