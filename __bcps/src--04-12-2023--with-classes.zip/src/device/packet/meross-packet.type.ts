export type IMerossPacketMethod =
  | 'GET'
  | 'SET'
  | 'GETACK'
  | 'SETACK'
  | 'PUSH'
  | 'ERROR'
  ;

export interface IMerossPacketHeader {
  readonly from: string;
  readonly messageId: string;
  readonly method: IMerossPacketMethod;
  readonly namespace: string; // name of the command
  readonly payloadVersion: 1;
  readonly sign: string; // md5(messageId + key + timestamp)
  readonly timestamp: number; // in s
  readonly timestampMs: number; // ms of the timestamp
}

export interface IMerossPacket<GPayload> {
  readonly header: IMerossPacketHeader;
  readonly payload: GPayload;
}

export type IGenericMerossPacket = IMerossPacket<any>;

