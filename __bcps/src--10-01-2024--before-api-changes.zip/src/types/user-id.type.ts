export type IUserId = string;

/**
 * @deprecated
 */
export interface IHavingUserId {
  readonly userId: IUserId;
}
