import { asyncFetchJSON, AsyncTask, IAbortableOptions, IAsyncFetchJSONFunction, IAsyncTaskConstraint } from '@lirx/async-task';
import { IHavingUserKey } from '../../../../types/having-user-key.type';
import { IGenericMerossPacket, IMerossPacket } from '../../meross-packet.type';
import { verifyMerossPacket } from '../../verify/verify-meross-packet';

export interface ISendHttpMerossPacketOptions extends IHavingUserKey, IAbortableOptions {
  readonly hostname: string;
  readonly packet: IGenericMerossPacket;
  readonly fetch?: IAsyncFetchJSONFunction;
}

/**
 * Sends a Meross Packet over http.
 *
 * Returns the payload of the response.
 */
export function sendHttpMerossPacket<GResponsePayload extends IAsyncTaskConstraint<GResponsePayload>>(
  {
    hostname,
    packet,
    fetch = asyncFetchJSON,
    key,
    abortable,
  }: ISendHttpMerossPacketOptions,
): AsyncTask<GResponsePayload> {
  const url: URL = new URL(`http://${hostname}/config`);

  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(packet),
  });

  return fetch<IMerossPacket<GResponsePayload>>(
    request,
    void 0,
    abortable,
  )
    .successful((merossResponsePacket: IMerossPacket<GResponsePayload>): GResponsePayload => {
      if (merossResponsePacket.header.messageId === packet.header.messageId) {
        verifyMerossPacket({
          packet,
          key,
        });
        // TODO ensure than packet is an ACK
        return merossResponsePacket.payload;
      } else {
        throw new Error(`Mismatching message id`);
      }
    });
}
